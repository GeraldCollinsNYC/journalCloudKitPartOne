//
//  EntryController.swift
//  journalCloudKit
//
//  Created by Collins on 12/7/20.
//

import Foundation
import CloudKit

class EntryController {
    
    //Shared Instance
    static let sharedInstance = EntryController()
    
    // Source of Truth  array
    var entries: [Entry] = [ ]
    
    // Constant to access Database
    let privateDB = CKContainer.default().privateCloudDatabase
    
    
    //MARK: - CRUD
    
    
    //Create
    func createEntry(with title: String, body: String, completion: @escaping(_ result: Result<Entry?, EntryError>) -> Void) {
        // initialize an Entry object. UUID and timestamp are handled dynamically
        let newEntry = Entry(title: title, body: body)
        saveEntry(entry: newEntry, completion: completion)
    }
    
    
    
    //Save
    func saveEntry(entry: Entry, completion: @escaping(_ result: Result<Entry?, EntryError>) -> Void) {
        
        // this is the same entry at the beginning of line 37's opening parentheses
        let entryRecord = CKRecord(entry: entry)
        privateDB.save(entryRecord) { (record, error) in
            if let error = error {
                print("Error in \(#function) : \(error.localizedDescription)")
                return completion(.failure(.ckError(error)))
            }
            guard let record = record,
                  let savedEntry = Entry(ckRecord: record)
            else { return completion(.failure(.couldNotUnwrap)) }
            print("Please work....")
            completion(.success(savedEntry))
        }
        
        
    }
    
    //Read
    func fetchEntriesWith(completion: @escaping(_ result: Result<[Entry]?,EntryError>) -> Void) {
        
        let predicate = NSPredicate(value: true)
        let query = CKQuery(recordType: EntryConstants.recordTypeKey, predicate: predicate)
        privateDB.perform(query, inZoneWith: nil) { (records, error) in
            if let error = error {
                print("Please work... \(#function) : \(error.localizedDescription)")
                completion(.failure(.ckError(error)))
            }
            guard let records = records else { return completion(.failure(.couldNotUnwrap))}
            print("Please pull the entries down")
            let entries = records.compactMap( { Entry(ckRecord: $0) })
            completion(.success(entries))
        }
    }
}
