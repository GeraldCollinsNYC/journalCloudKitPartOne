//
//  EntryError.swift
//  journalCloudKit
//
//  Created by Collins on 12/7/20.
//

import Foundation
import CloudKit

enum EntryError: LocalizedError {
    case ckError(Error)
    case couldNotUnwrap
    
    var errorDescription: String {
        switch self {
        case .ckError(let error):
            return error.localizedDescription
        case .couldNotUnwrap:
            return "Please come back Mr. and Mrs. Entry... please..."
        }
    }
}
